﻿using DomainLayer.Models.Enums;

namespace DomainLayer.Models.Enums
{
    public enum Sexo
    {
        Masculino,
        Feminino
    }
}