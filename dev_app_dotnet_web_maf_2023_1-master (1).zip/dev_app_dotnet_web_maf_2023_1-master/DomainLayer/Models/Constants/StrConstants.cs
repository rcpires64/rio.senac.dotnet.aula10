﻿namespace DomainLayer.Models.Constants
{
    public static class StrConstants
    {
        public const string SemConhecimento = "Sem conhecimento definido";
        public const string Aprovado = "Aprovado";
        public const string Reprovado = "Reprovado";
        public const string Recuperacao = "Recuperação";
    }
}

