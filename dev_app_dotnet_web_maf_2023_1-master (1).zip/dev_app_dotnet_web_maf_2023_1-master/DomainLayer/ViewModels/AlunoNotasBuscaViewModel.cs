﻿namespace DomainLayer.ViewModels
{
    public class AlunoNotaBuscaViewModel : AlunoCadastroViewModel
    {
        public double Nota { get; set; } = default!;
    }
}
